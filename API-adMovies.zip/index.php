<?php

use Controllers\Router;
use Controllers\UserController;
use Dotenv\Dotenv;
require "vendor/autoload.php";

// Charger les variables d'environnement
$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load();
header("Access-Control-Allow-Origin: *");

// Vérifier les cookies et connecter l'utilisateur automatiquement
$userController = new UserController();
$userController->autoLogin();

$routeur = new Router("Controllers");
session_start(); 
$_SESSION['id'] = 1;
$_SESSION['name'] = 'lorem upsom dollars 12';
$_SESSION['email'] = "accrodev@gmail.com";
$_SESSION['accreditation'] = 1; 

$routeur 
    // path, class@methode, name
    ->get("/search","Search@search","search")
    ->get("/add-movie","MovieAutoAdd@addMovie","addMovie")
    ->get("/create-index","Search@createIndex","createIndex")
    ->get("/vote/[i:id]","SeriesVote@voteOrDevote","voteOrDevote")
    ->get("/top-recommended","SeriesVote@getTopRecommended","topRecommended")
    ->get("/addShopMovie","ShopController@addShopMovie","addShopMovie")
    ->post("/create-shop","ShopController@createShop","createShop")
    //get movie from shop
    ->get("/get/[i:id]","ShopController@getShopMovies","getShopMovies")
    //get all shops of one user
    ->get("/get-shops","ShopController@getShops","getShops")
    //get all shops of one user
    ->get("/get-user-shops","ShopController@getShops","getUserShops")
    ->get("/movies","MovieController@getMovies","getMovies")
    ->get("/movie/[i:id]","MovieController@getMovieById","getMovieById")
    ->post("/register","UserController@register","register")
    ->post("/confirm","UserController@confirm","confirm")
    ->post("/login","UserController@login","login")
    ->post("/forgot-password","UserController@forgotPassword","forgotPassword")
    ->post("/reset-password","UserController@resetPassword","resetPassword")
    ->post("/delete-shop","ShopController@deleteShop","deleteShop")
    ->get("/logout","UserController@logout","logout")
    ->run();
?>